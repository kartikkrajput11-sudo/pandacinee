import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../supabase_providers.dart';
import '../theme.dart';
import 'notifications_screen.dart';
import 'streak_card.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final profile = ref.watch(profileProvider);
    return Scaffold(
      body: SafeArea(
        child: profile.when(
          loading: () => const Center(child: CircularProgressIndicator(color: AppColors.petal)),
          error: (e, _) => Center(child: Text('Error: $e')),
          data: (p) {
            final name = (p?['display_name'] ?? p?['username'] ?? 'panda') as String;
            return ListView(
              padding: const EdgeInsets.fromLTRB(24, 32, 24, 32),
              children: [
                Row(children: [
                  Expanded(child: Text('Chapter · Home', style: eyebrow())),
                  const NotificationBell(),
                  IconButton(
                    icon: const Icon(Icons.settings_outlined, color: AppColors.candle),
                    onPressed: () => context.push('/app/settings'),
                  ),
                ]),
                const SizedBox(height: 4),
                Text('Hello, $name', style: serifItalic(size: 40))
                    .animate().fadeIn().slideY(begin: .1),
                const SizedBox(height: 8),
                const Text(
                  'Your velvet room is ready.',
                  style: TextStyle(color: AppColors.candleMuted),
                ),
                const SizedBox(height: 22),
                const StreakCard(),
                const SizedBox(height: 24),
                _card(context, 'Chats', 'DMs, groups, affections', onTap: () => context.push('/app/chats')),
                _card(context, 'Play', 'Chess, Ludo, Uno, Pool…', onTap: () => context.push('/app/play')),
                _card(context, 'Movies', 'Watch in lock-step', onTap: () => context.push('/app/movies')),
                _card(context, 'Profile', 'Badges & achievements', onTap: () => context.push('/app/me')),
                _card(context, 'Affections', 'Kiss · Hug · Headpat…', onTap: () => context.push('/app/affections')),
                _card(context, 'Groups', 'Rooms, codes, matches', onTap: () => context.push('/app/groups')),
                _card(context, 'Vault', 'Letters, capsules, memory', onTap: () => context.push('/app/vault')),
                _card(context, 'Daily', 'Prompt & mood log', onTap: () => context.push('/app/daily')),
                _card(context, 'Shop', 'Panda Coins & petals', onTap: () => context.push('/app/shop')),
                _card(context, 'Locked chapter', 'Word verification', onTap: () => context.push('/app/locks')),
                _card(context, 'Calls', 'Voice & video ringing', onTap: () => context.push('/app/calls')),
                _card(context, 'Admin', 'Flags · animations · broadcast', onTap: () => context.push('/app/admin')),
                _card(context, 'Walk-through', 'Tour signature features', onTap: () => context.push('/app/tour')),
                const SizedBox(height: 30),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _card(BuildContext context, String title, String subtitle, {VoidCallback? onTap}) =>
      Padding(
        padding: const EdgeInsets.only(bottom: 14),
        child: Material(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(20),
          child: InkWell(
            onTap: onTap,
            borderRadius: BorderRadius.circular(20),
            child: Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: AppColors.border),
              ),
              child: Row(
                children: [
                  Container(width: 4, height: 32, color: AppColors.coral),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(title, style: serifItalic(size: 22, color: AppColors.candle)),
                        const SizedBox(height: 2),
                        Text(subtitle,
                            style: const TextStyle(color: AppColors.candleMuted, fontSize: 13)),
                      ],
                    ),
                  ),
                  const Icon(Icons.arrow_forward, color: AppColors.petal, size: 18),
                ],
              ),
            ),
          ),
        ),
      );
}
